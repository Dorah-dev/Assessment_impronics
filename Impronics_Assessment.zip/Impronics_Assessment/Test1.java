//Find the highest common factor 
//(https://en.wikipedia.org/wiki/Greatest_common_divisor) for 
//a given array of integers
 
/*
* Using if and else statement to find the Greatest Common Divisor
*/
public class GreatestCommonDivisor {
 public static int getGreatestCommonDivisor (int first, int second) {
 if (first < 10 || second < 10) {
 return -1;
 }
 
 int GCD = 1;
 int firstHolder = first;
 int secondHolder = second;
 
 if (first < second) {
 for (int i = 1; i<first+1; i++) {
 if (firstHolder % i == 0 && secondHolder % i == 0) {
 GCD = i;
 }
 }
 }
 else {
 for (int i = 1; i<second+1; i++) {
 if (firstHolder % i == 0 && secondHolder % i == 0) {
 GCD = i;
 }
 }
 }
 return GCD; 
 }
}

//Solution 2

//Factors of 12: 1, 2, 3, 4, 6, 12
//Factors of 8: 1, 2, 4, 8
//Common Factors: 1, 2, 4
//Greatest Common Factor: 4
//Hence, the GCF of 12 and 8 is 4.
//Algorithm to Find GCD
// Declare two variables, say x and y.
// Run a loop for x and y from 1 to max of x and y.
// Check that the number divides both (x and y) numbers completely or not. 
//If divides completely store it in a variable.
//Divide the stored number.
//Using Java while Loop
//In the following example, we have used while loop to test the condition. The loop 
//executes until the condition n1!=n2 becomes false.
//FindGCDExample2.java
// example Java function definition
public class FindGCDExample2 
{ 
public static void main(String[] args) 
{ 
int n1=50, n2=60; 
while(n1!=n2) 
{ 
if(n1>n2) 
n1=n1-n2; 
else 
n2=n2-n1; 
} 
System.out.printf("GCD of n1 and n2 is: " +n2); 
} 
} 
Output 
GCD of n1 and n2 is 10GCGCD of n1 and n2 is: 10
GCD of n1 and n2 is: 10