//Write a function to pretty print all the addresses in the 
//attached file
//One possible way to do this for any object without the use of an external library 
//would be to use reflection of a generic type. In the following snippet, we simply 
//access each field (including private fields) and print their name and value:
public static <T> String printObject(T t) {
 StringBuilder sb = new StringBuilder();
 for (Field field : t.getClass().getDeclaredFields()) {
 field.setAccessible(true);
 try {
 sb.append(field.getName()).append(": ").append(field.get(t)).append('\n');
 } catch (Exception e) {
 e.printStackTrace();
 }
 }
 return sb.toString();
}
//This method could be placed in a utility class for easy access.
//If any of the object's fields do not override Object#toString it will simply print the 
//object's type and its hashCode.
//Example:
public class Test {
 private int x = 5;
 private int y = 10;
 private List<List<Integer>> list = Arrays.asList(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6));
}
>> printObject(new Test());
>>
>> x: 5
>> y: 10
>> list: [[1, 2, 3], [4, 5, 6]]
c. Write a function to print an address of a certain type (postal, 
physical, business)
public class Address {
 private String street;
 private String city;
 private String state;
 private String zip;
 public Address(String addressStreet, String addressCity, String 
addressState, String addressZip) {
 street = addressStreet;
 city = addressCity;
 state = addressState;
 zip = addressZip;
}
public String getStreet(){
return street;
}
public String getCity(){
return city;
}
public String getState() {
return state;
}
public String getZip() {
return zip;
}
public String toString() {
return street +
 city +
 state +
 zip;
}
}